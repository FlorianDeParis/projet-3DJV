For creating translation file
=============================

1. Copy the "cpm.pot" file to "cpm-<YOUR_LANGUAGE_CODE>.po". e.g: "cpm-fr_FR.po"
2. Open the "cpm-<YOUR_LANGUAGE_CODE>.po" in "Poedit" software and translate the strings.

jQuery(document).ready(function() {
	jQuery("#settings").hide();
	jQuery("h4.SE_settings").click(function() {
		jQuery("#settings").slideToggle();
	});
});
 
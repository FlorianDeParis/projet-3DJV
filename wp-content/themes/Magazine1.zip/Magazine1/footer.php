<div id="footer">

<p>
	<?php $theme_options = get_option('Mag1'); ?>
    <?php ftr_fx($theme_options['mag1_custom_footer']); ?>

</p>

</div>


</div>

</body>
</html>